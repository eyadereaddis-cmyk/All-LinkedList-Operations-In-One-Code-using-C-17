# Code of Conduct

We expect all contributors to:
- Be respectful
- Avoid offensive language
- Help beginners kindly
- Share knowledge openly
